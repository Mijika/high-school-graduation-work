#ifndef _ACTION_
#define _ACTION_

#include "Arduino.h"

#define LED_RIGHT 5 //오른쪽 전등의 제어 핀
#define LED_LEFT 6 //왼쪽 전등의 제어 핀


#define MOVE_MOTOR_RIGHT_EN1 10 //오른쪽 모터의 방향 지시 핀 1
#define MOVE_MOTOR_RIGHT_EN2 11 //오른쪽 모터의 방향 지시 핀 2
#define MOVE_MOTOR_RIGHT_PWM 12 //오른쪽 모터의 pwm 핀
#define MOVE_MOTOR_RIGHT_PWM_CH 0 //오른쪽 모터의 pwm 채널

#define MOVE_MOTOR_LEFT_EN1 13 //왼쪽 모터의 방향 지시 핀 1
#define MOVE_MOTOR_LEFT_EN2 14 //왼쪽 모터의 방향 지시 핀 2
#define MOVE_MOTOR_LEFT_PWM 15 //왼쪽 모터의 pwm 핀
#define MOVE_MOTOR_LEFT_PWM_CH 1 //왼쪽 모터의 pwm 채널

#define DIAMETER_MOTOR_EN1 13 //바퀴 지름 제어 모터의 방향 지시 핀 1
#define DIAMETER_MOTOR_EN2 14 //바퀴 지름 제어 모터의 방향 지시 핀 2
#define DIAMETER_MOTOR_PWM 15 //바퀴 지름 제어 모터의 pwm 핀
#define DIAMETER_MOTORPWM_CH 2 //지름 모터의 pwm 채널

#define MOVE_MOTOR_SPD 100 //이동 모터의 스피드
#define MOVE_DIAMETER_MOTOR_SPD 10 //지름 모터의 딜레이

class Action {
    public :
        //초기화 함수
        Action();

        //LED 모듈에 불 들어 오게하는 코딩
        void led_on(void); //LED 전등 온
        void led_off(void); //LED 전등 오프

        //이동 모터 4가지 모드 코딩(void전진, 후진, 왼쪽 턴, 오른쪽 턴)
        void move_forward(void); //모터 전진
        void move_reverse(void); //모터 후진
        void move_left_turn(void); //모터 좌회전
        void move_right_turn(void); //모터 우회전
        void move_stop(void); //모터 정지

        //지름 모터 앞, 뒷 2가지 모드 코딩(void지름 커짐, 작아짐)
        void diameter_up(void); // 지름 증가
        void diameter_down(void); // 지름 감소
};

#endif
